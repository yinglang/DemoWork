# coding=utf-8
from PIL import Image
files = '1 2 3 4 5 7 8 9 10 11 12 13 14 15 16 17 19 20'.split(' ')
for file in files:
	im = Image.open(file+'.png')
	im = im.resize((800, 600))
	im.save(file + ".png")